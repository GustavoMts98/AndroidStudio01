package com.example.qrcode2n

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.google.zxing.integration.android.IntentIntegrator

class MainActivity : AppCompatActivity() {
    //  toda tela no android é uma activity
    // um leitor de qrcode para cada tipo de QR, endereço, prateleira,rua
    // quero ler endereço então chamo o lambda que le o endereço

    private val obterResultado = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val intentResult = IntentIntegrator.parseActivityResult(it.resultCode, it.data)
        if (intentResult.contents != null) {
            Toast.makeText(this, intentResult.contents, Toast.LENGTH_LONG).show()

//          Daqui pra baixo é onde devemos alterar, nexte exemplo ele espera uma URL
            val navegador = Intent(Intent.ACTION_VIEW)
            navegador.data = Uri.parse(intentResult.contents)
            startActivity(navegador)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnLerQrCode: Button = findViewById(R.id.btnLerQrCode)
        btnLerQrCode.setOnClickListener {
            val integrator: IntentIntegrator = IntentIntegrator(this)
            integrator.setPrompt("Leitura de QRCode")
            obterResultado.launch(integrator.createScanIntent())
        }

    }
}