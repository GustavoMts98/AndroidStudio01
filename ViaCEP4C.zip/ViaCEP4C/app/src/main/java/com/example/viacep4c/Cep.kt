package com.example.viacep4c

class Cep {

    private val cep: String
    private val logradouro: String
    private val complemento: String
    private val bairro: String
    private val localidade: String
    private val uf: String
    private val ibge: String
    private val gia: String
    private val ddd: String
    private val siafi: String
    constructor(cep: String, logradouro: String, complemento: String,
                bairro: String, localidade: String, uf: String,
                ibge: String, gia: String, ddd: String, siafi: String) {
        this.cep = cep
        this.logradouro = logradouro
        this.complemento = complemento
        this.bairro = bairro
        this.localidade = localidade
        this.uf = uf
        this.ibge = ibge
        this.gia = gia
        this.ddd = ddd
        this.siafi = siafi
    }
    fun getCep(): String = this.cep
    fun getLogradouro(): String = this.logradouro
    fun getComplemento(): String = this.complemento
    fun getBairro(): String = this.bairro
    fun getLocalidade(): String = this.localidade
    fun getUf(): String = this.uf
    fun getIbge(): String = this.ibge
    fun getGia(): String = this.gia
    fun getDdd(): String = this.ddd
    fun getSiafi(): String = this.siafi
}