package com.example.viacep4c

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.gson.Gson
import java.net.URL

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnPesquisa: Button = findViewById(R.id.btnPesquisa)
        btnPesquisa.setOnClickListener{
            val edtCep: EditText = findViewById(R.id.edtCep)
            val url = "https://viacep.com.br/ws/" + edtCep.text + "/json/"
            consulta(url)
        }
    }

    private fun consulta(url: String) {
        val txtLogradouro: TextView = findViewById(R.id.txtLogradouro)
        val txtComplemento: TextView = findViewById(R.id.txtComplemento)
        val txtBairro: TextView = findViewById(R.id.txtBairro)
        val txtLocalidade: TextView = findViewById(R.id.txtLocalidade)
        val txtEstado: TextView = findViewById(R.id.txtEstado)
        Thread(Runnable {
            try {
                val json = URL(url).readText()
                val cep = Gson().fromJson(json, Cep::class.java)
                this@MainActivity.runOnUiThread(java.lang.Runnable {
                    txtLogradouro.setText(cep.getLogradouro())
                    txtComplemento.setText(cep.getComplemento())
                    txtBairro.setText(cep.getBairro())
                    txtLocalidade.setText(cep.getLocalidade())
                    txtEstado.setText(cep.getUf())
                })
            } catch (e: Exception) {
                Toast.makeText(applicationContext, "Erro ao acessar ViaCep", Toast.LENGTH_LONG)
                    .show()
            }
        }).start()
    }


}
