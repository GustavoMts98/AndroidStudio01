package com.example.vagalume4c

class Artista {

    private val id: String
    private val name: String
    private val url: String
    private val pic_small: String
    private val pic_medium: String
    private val rank: String

    constructor(id: String, name: String, url: String,
                pic_small: String, pic_medium: String,
                rank: String = "0") {
        this.id = id
        this.name = name
        this.url = url
        this.pic_small = pic_small
        this.pic_medium = pic_medium
        this.rank = rank
    }

    fun getId(): String = this.id
    fun getName(): String = this.name
    fun getUrl(): String = this.url
    fun getPicSmall(): String = this.pic_small
    fun getPicMedium(): String = this.pic_medium
    fun getRank(): String = this.rank
}
