package com.example.vagalume4c

class Musica {

    private val id: String
    private val name: String
    private val url: String
    private val uniques: String
    private val views: String
    private val rank: String
    private val art: Artista

    constructor(id: String, name: String, url: String, uniques: String,
                views: String, rank: String, art: Artista) {
        this.name = name
        this.url = url
        this.rank = rank
        this.uniques = uniques
        this.views = views
        this.id = id
        this.art = art
    }

    fun getId(): String = this.id
    fun getName(): String = this.name
    fun getUrl(): String = this.url
    fun getUniques(): String = this.uniques
    fun getViews(): String = this.views
    fun getRank(): String = this.rank
    fun getArt(): Artista = this.art
}