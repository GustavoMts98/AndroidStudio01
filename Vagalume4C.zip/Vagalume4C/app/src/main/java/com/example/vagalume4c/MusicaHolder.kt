package com.example.vagalume4c

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MusicaHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    var nomeMusica: TextView
    var visualizacoes: TextView
    init {
        nomeMusica = itemView.findViewById(R.id.nomeMusica)
        visualizacoes = itemView.findViewById(R.id.visualizacoes)
    }
}
