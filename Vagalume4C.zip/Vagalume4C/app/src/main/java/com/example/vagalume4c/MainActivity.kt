package com.example.vagalume4c

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    lateinit var musicasJson: String
    lateinit var periodoJson: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val spnPeriodo: Spinner = findViewById(R.id.spnPeriodo)
        val adapter = ArrayAdapter.createFromResource(
            this, R.array.periodos, android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnPeriodo.adapter = adapter
        spnPeriodo.setSelection(0);

        val btnPesquisa: Button = findViewById(R.id.btnPesquisa)
        btnPesquisa.setOnClickListener {
            val url = getMontaUrl(spnPeriodo)
            getMusicasJson(url)
        }


    }

    private fun getMontaUrl(spnPeriodo: Spinner): String {
        val principal = "https://api.vagalume.com.br/rank.php?"
        val apiKey = "apikey=9b30f2225433f7e35ad0a001b7472bfd"
        val tipo = "&type=mus"
        val escopo = "&scope=internacional"
        val quantidade = "&limit=10"
        var periodo = "&period="
        if (spnPeriodo.selectedItem == "Diário") {
            periodo = periodo+"day"
        } else if (spnPeriodo.selectedItem == "Semanal") {
            periodo = periodo+"week"
        } else if (spnPeriodo.selectedItem == "Mensal") {
            periodo = periodo+"month"
        } else {
            periodo = periodo+"day"
        }
        return principal+apiKey+tipo+periodo+escopo+quantidade
    }

    private fun getMusicasJson(json: String): String {
        val spnPeriodo: Spinner = findViewById(R.id.spnPeriodo)
        val rank = JSONObject(json)
        val musJson = rank.getString("mus")
        if (spnPeriodo.selectedItem == "Diário") {
            val dia = JSONObject(musJson)
            periodoJson = dia.getString("day")
        } else if (spnPeriodo.selectedItem == "Semanal") {
            val week = JSONObject(musJson)
            periodoJson = week.getString("week")
        } else if (spnPeriodo.selectedItem == "Mensal") {
            val month = JSONObject(musJson)
            periodoJson = month.getString("month")
        }
        val musicas = JSONObject(periodoJson)
        return musicas.getString("all")
    }

}
