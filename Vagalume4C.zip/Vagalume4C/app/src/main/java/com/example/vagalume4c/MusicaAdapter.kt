package com.example.vagalume4c

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class MusicaAdapter(lMusicas: List<Musica?>?) : RecyclerView.Adapter<MusicaHolder>() {

    private val listaMusicas: List<Musica>?
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MusicaHolder {
        return MusicaHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.musicas, parent, false)
        )
    }
    override fun onBindViewHolder(holder: MusicaHolder, position: Int) {
        holder.nomeMusica.setText(listaMusicas!![position].getName())
        holder.visualizacoes.setText(listaMusicas!![position].getRank())
    }
    override fun getItemCount(): Int {
        return listaMusicas?.size ?: 0
    }
    init {
        this.listaMusicas = lMusicas as List<Musica>?
    }
}