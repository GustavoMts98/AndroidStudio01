package com.example.mediaescolar_2n

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val resultado: TextView = findViewById(R.id.resultado)
        val edtNota01 : EditText = findViewById(R.id.edtNota01)
        val edtNota02: EditText = findViewById(R.id.edtNota02)
        val soma : Int = (edtNota01.text.toString() + edtNota02.text.toString()).toInt()
        val media : Int = soma / 2

        val btnCalcular: Button = findViewById(R.id.Calcular)


        btnCalcular.setOnClickListener {
            if(media >= 6 ){
                resultado.setText("Aprovado")
                Toast.makeText(applicationContext,"Você foi aprovado", Toast.LENGTH_LONG).show()
            } else if (media <= 1 ){
                resultado.setText("Reprovado")
                Toast.makeText(applicationContext,"Você foi reprovado", Toast.LENGTH_LONG).show()
            } else {
                resultado.setText("Recuperação")
                Toast.makeText(applicationContext,"Você está de recuperação", Toast.LENGTH_LONG).show()
            }
        }
    }
}