package com.example.ciclodevida2n

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text

class SegundaTela : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda_tela)

        val primeiraTela = intent
        val parametros = primeiraTela.extras
        val sNome = parametros?.getString("Nome")
//      ? caso nao tenha valor ele retorna null

        val txtSegundaTela: TextView = findViewById(R.id.txtSegundaTela)
        txtSegundaTela.text = sNome

        val btnFechar : Button = findViewById(R.id.btnFechar)

        btnFechar.setOnClickListener {
            finish()
        }
    }


}