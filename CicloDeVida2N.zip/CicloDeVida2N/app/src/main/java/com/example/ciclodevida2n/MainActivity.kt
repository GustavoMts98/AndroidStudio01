package com.example.ciclodevida2n

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnAbrirSegundaTela : Button = findViewById(R.id.btnSegundaTela)

        val btnFechar : Button = findViewById(R.id.btnFechar)

        val btnNavegaor : Button = findViewById(R.id.btnAbrirNavegador)

        btnAbrirSegundaTela.setOnClickListener {

            //passar o contexto "this" que é essa classe e a activity (class) que queremos abrir
            val segundaTela = Intent(this,SegundaTela::class.java)

            val parametros = Bundle()
            parametros.putString("Nome","Majola")
            segundaTela.putExtras(parametros)

//            segundaTela.putExtra("Nome", "Majola")

            startActivity(segundaTela)

        }

        btnFechar.setOnClickListener {
            finish()
        }

        btnNavegaor.setOnClickListener {
//       Passar uma intenção
            val navegador = Intent(Intent.ACTION_VIEW)
            navegador.data = Uri.parse("http://www.unicid.edu.br")
            startActivity(navegador)
        }


    }



    override fun onStart() {
        super.onStart()

        Toast.makeText(applicationContext, "onStart Selecionado", Toast.LENGTH_SHORT).show()
    }

    override fun onRestart() {
        super.onRestart()

        Toast.makeText(applicationContext, "onRestart Selecionado", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()

        Toast.makeText(applicationContext, "onResume Selecionado", Toast.LENGTH_SHORT).show()
    }

    override fun onPause() {
        super.onPause()

        Toast.makeText(applicationContext, "onPause Selecionado", Toast.LENGTH_SHORT).show()
    }

    override fun onStop() {
        super.onStop()

        Toast.makeText(applicationContext, "onPause Selecionado", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()

        Toast.makeText(applicationContext, "onDestroy Selecionado", Toast.LENGTH_SHORT).show()
    }
}